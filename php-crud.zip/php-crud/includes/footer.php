<footer>
<p>&copy; <?php echo date("Y"); ?> Youtubers, Inc. By Ciaran Mullen</p>
</footer>